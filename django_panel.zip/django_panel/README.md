# django_panel
panel de administración creado con django

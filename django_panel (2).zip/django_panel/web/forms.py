from django.forms import ModelForm
from .models import *
class AlumnoForm(ModelForm):
    class Meta:
        model = TblAlumno
        fields = '__all__'

class CursoForm(ModelForm):
    class Meta:
        model = TblCurso
        fields = '__all__'